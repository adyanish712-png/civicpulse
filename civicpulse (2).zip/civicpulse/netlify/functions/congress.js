const API_KEY = 'GuXIhy31WfeoqvI0AlLINTPy4pacfXHY93k7s7QV';
const API_BASE = 'https://api.congress.gov/v3';

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { endpoint } = event.queryStringParameters || {};
    if (!endpoint) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing endpoint parameter' }) };
    }

    const url = `${API_BASE}/${endpoint}&api_key=${API_KEY}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Congress.gov API error: ${response.status}`);
    }

    const data = await response.json();
    return { statusCode: 200, headers, body: JSON.stringify(data) };

  } catch (err) {
    return {
      statusCode: 500, headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
